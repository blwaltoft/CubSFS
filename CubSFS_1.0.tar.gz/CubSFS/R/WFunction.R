#' A Polanski and Kimmel matrix
#' 
#' @param n the number of sequences
#' 
#' @return a matrix of dimension \eqn{(n-1)\times (n-1)}.
#'
#' @references 
#' Polanski, A. and Kimmel, M. (2003), "New Explicit Expressions for Relative Frequencies of Single-Nucleotide Polymorphisms With Application 
#' to Statistical Inference on Population Growth." Genetics, 165, 427-436.
#' @export 

WFunction <-
function(n.samples){
  return(matrix( unlist( lapply(1:(n.samples-1),WijFunction,n=n.samples) ),
                byrow=TRUE,nrow=(n.samples-1)) )
}
