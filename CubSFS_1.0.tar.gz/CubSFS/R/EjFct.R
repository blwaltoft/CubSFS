#' Estimate of \eqn{e_j}.
#'
#' Estimate 
#' \deqn{e_j=\int_0^{\infty}\exp(-{j \choose 2}\Lambda(t))dt,}{e_j=integral_0^{\infty} exp( -{j \choose 2} \Lambda(t) ) dt,} 
#' for \eqn{j=2,3,\ldots,n} by assuming \eqn{\Lambda(t)} is composed of piece wise straight lines between two points.
#' 
#' The points defining the straight lines are given by \code{seq(0,max(konts),len=nb.time)}. The values of the function 
#' \eqn{\Lambda(t)} at the time points are determined by the spline given by \code{par} and \code{knots}. The spline is given as
#' \deqn{\Lambda (t) = a_i + b_i (t-t_i) + c_i (t-t_i)^2 + d_i (t-t_i)^3 for t_i\leq t < t_{i+1},}{\Lambda (t) = 
#' a_i + b_i (t-t_i) + c_i (t-t_i)^2 + d_i (t-t_i)^3 for t_i\le t < t_{i+1},}
#' where \eqn{\Lambda(t) = a_m + b_m (t-t_m)} for \eqn{t_m \leq t}{t_m \le t}, \eqn{\Lambda'(0)=b_0=1} and \eqn{\Lambda(0)=0}.
#' 
#' For given time points \eqn{t_i} for \eqn{i=0,1,\ldots,m} and  values \eqn{a_0=\Lambda(0)=0, \Lambda(t_1) = a_1, \ldots, \Lambda(t_m)=a_m},
#' the spline is completly specified. 
#' 
#' When this function is used during the estimation of the changes in population size then \eqn{n}\code{=n.samples}, 
#' which is the number of sequences used to generate the site frequency spectrum, from which the changes in population size is infered.
#'   
#' @param par the value of \eqn{\Lambda} in the \code{konts}, i.e. \eqn{\Lambda(t_i) = a_i}.
#' @param knots the time points at which the value of the spline is \code{par}. \eqn{t_0=0<t_1<t_2<\ldots,t_m}.
#' @param n.samples \eqn{n}. 
#' @param nb.time the number of time points in the fine partitioning. Default=500.
#' 
#' @return 
#' a vector of lenght \code{n.samples}-1. The \eqn{j}'th entry is \eqn{e_j(\Lambda)} for \eqn{j= 2,3,...,}\code{n.samples}.
#' 
#' @seealso \code{\link{SplineFct}} 
#' 
#' @export 

EjFct <-
function(par,knots,n.samples,nb.time=500){

  tt <- seq(0,max(knots),len=nb.time)
  est.spl <- SplineFct(tt,par,knots)
  est.par <- est.spl$spline$value
  slp.prm <- diff(est.par)/diff(tt) 
  
  x1 <- 1/outer(choose(2:n.samples,2),slp.prm)
  x2 <- exp(-outer(choose(2:n.samples,2),est.par[-length(est.par)]))
  x3 <- exp(-outer(choose(2:n.samples,2),est.par[-length(est.par)]+slp.prm*diff(tt)))
  evecMat <- x1*(x2-x3)

  b_n <- est.spl$bb.spl[length(knots)]
  x4 <- exp(-choose(2:n.samples,2)*par[length(par)])/(choose(2:n.samples,2)*b_n)

  return(rowSums(evecMat)+x4)
}
