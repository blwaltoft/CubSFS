
#' calculate the Square error given a single training site frequency spectrum (SFS).
#' 
#' Given a training SFS, calculate the square error of the validation SFS \eqn{\xi^{(k)}}{\xi^(k)} 
#' \deqn{\sum\limits_{i=1}^{n-1} \frac{\left(\xi_i^{(k)}-E[\xi_i^{(k)}]\right)^2}{E[\xi_i^{(k)}]}.}{\sum_{i=1}^{n-1} ( \xi_i^(k) - E[\xi_i^(k)] )^2 / E[\xi_i^(k)].}
#' 
#' The expected validation SFS \eqn{E[\xi^{(k)}]}{E[ \xi^(k) ]} is evaluated using the spline estimated by the training SFS.
#' 
#' The spline is given as
#' \deqn{\Lambda = a_i + b_i (t-t_i) + c_i (t-t_i)^2 + d_i (t-t_i)^3 for t_i\leq t < t_{i+1},}{\Lambda = 
#' a_i + b_i (t-t_i) + c_i (t-t_i)^2 + d_i (t-t_i)^3 for t_i\le t < t_{i+1},}
#' where \eqn{\Lambda(t) = a_m + b_m (t-t_m)} for \eqn{t_m \leq t}{t_m \le t}, \eqn{\Lambda'(0)=b_0=1} and \eqn{\Lambda(0)=0}.
#' 
#' For given time points \eqn{t_i} for \eqn{i=0,1,\ldots,m} and  values \eqn{a_0=\Lambda(0)=0, \Lambda(t_1) = a_1, \ldots, \Lambda(t_m)=a_m},
#' the spline is completly specified. Hence, the score function is minimized wrt. \eqn{a_0, a_1, \ldots, a_m} given some time points.
#' A reparameterisation is used \eqn{\psi_i=a_{i}-a_{i-1}} for \eqn{i=1,2,\ldots,m}.
#'
#' Given a spline \eqn{\Lambda(t)} and the smoothing parameter \eqn{\alpha}, 
#' the score function is
#' \deqn{S(\Lambda)= (1-\alpha)\sum\limits_{i=1}^{n-1}\frac{\left(\E[\xi_i]-\xi_i\right)^2}{\E[\xi_i]}+
#' \alpha\int\limits_{0}^{\infty}\left(\Lambda''(t)\right)^2dt.}{S(\Lambda) = (1-\alpha) * 
#' \sum_{i=1}^{n-1} ( E[\xi_i] - \xi_i )^2 / E[\xi_i] +
#' \alpha * intergral_{0}^{\infty} ( \Lambda''(t) )^2 dt.}
#'
#' The probability of observing a site with \eqn{i} derived alleles is evaluated using the formula by Polanski and Kimmel (2003)
#' \deqn{p_i(\Lambda)=\frac{\sum\limits_{j=2}^ne_j (\Lambda)W_{ij}}{\sum\limits_{j=2}^n e_j(\Lambda)V_j}}{p_i(\Lambda) = ( \sum_{j=2}^n e_j(\Lambda) W_{ij} ) / ( \sum_{j=2}^n e_j(\Lambda) V_j )}
#' for \eqn{i=1,2,\ldots,n-1} for unfolded SFS (\code{is.folded=F}). For the folded SFS the probability of observing a site with minor 
#' allele count \eqn{i} among \eqn{n} sequences is 
#' \deqn{p_i^F(\Lambda) = p_i(\Lambda) + p_{n-i}(\Lambda)}
#' for \eqn{i=1,\ldots,n/2} if \eqn{n} is even and for \eqn{n} odd
#' \deqn{p_i^F(\Lambda) = p_i(\Lambda) + p_{n-i}(\Lambda)}
#' for \eqn{i=1,\ldots,(n-1)/2} and \eqn{p_{(n+1)/2}^F(\Lambda) = p_{(n+1)/2}(\Lambda)}.
#' 
#' Here \eqn{e_j(\Lambda)} is evaluated using \code{\link{Ejfct}}.
#' 
#' The expected SFS \eqn{E[\xi]^{(k)}}{E[\xi]^(k)} is estimated by the total number of segregating sites in group \eqn{k} 
#' multiplied by the above probabilities.
#' 
#' The roughness penalty is evaluated by a linear equation system, implemented in \code{\link{SplineFct}}.
#' 
#' @param i.group indicates the training set.
#' @param SFS.groups a matrix of dimension (\code{n.samples-1})x(\code{nb.groups}) if \code{is.folded=F} 
#' or dimension (\code{n.samples/2})x(\code{nb.groups}) if \code{is.folded=T} and the species is diploid.
#' Each column holds the SFS of one group of sites. The \code{i.group} column is the training set, 
#' the row sums of the rest of the columns compose the validation set.
#' @param n.samples the number of sequences used to generate the observed SFS.
#' @param knots the time points \eqn{t_i} for \eqn{i=0,\ldots,m} where \eqn{t_0=0}.
#' @param theta.prm the parameters specifiing the spline \code{theta.prm[i]}\eqn{=psi[i]=a_i-a_{i-1}} for \eqn{i=1,2,\ldots,m}, where \eqn{\Lambda(t_i)=a_i}.
#' @param alpha the smoothing parameter.
#' @param Wmat,Vmat the Polanski and Kimmel matrices.
#' @param is.folded is the SFS folded(True) or unfolded (False).
#' @param nb.time the number of time points used to estimate \eqn{e_j(\Lambda)}
#' @param loc.solv the local solver. May be either \code{COBYLA} or \code{LBFGS}.
#' @param conv.lim the desired accuracy of the paraemters.
#' @inheritParams nloptr::auglag
#' 
#' @return An integer: The square error for the \code{i}'th validation set.
#' 
#' @seealso \code{\link{estimateAlpha}} \code{\link{CValpha}} \code{\link{estimateCubSFS}}
#' 
#' @references 
#' Polanski, A. and Kimmel, M. (2003), "New Explicit Expressions for Relative Frequencies of Single-Nucleotide Polymorphisms With Application 
#' to Statistical Inference on Population Growth." Genetics, 165, 427-436.
#' 
#' Waltoft and Hobolth (2017) Non-Parametric Estimation Of Population Size Changes From The Site Frequency Spectrum, 
#' doi: https://doi.org/10.1101/125351 
#' 
## @examples 
## rawSFS <- c(1925,867,532,372,280,221,181,151,129,111,98,87,77,70,63,58,53,49,45,42,39,36,34,32,30,28,27,25,24,23,22,21,20,19,18,17,17,16,15,15,14,14,13,13,12,12,12,11,11)
##
## Wmat <- WFunction(n.samples)
## Vmat <- VFunction(n.samples)
#'
#' 
#' @export

helpCValpha <-
function(i.group,SFS.groups,n.samples,knots,theta.prm,alpha,Wmat,Vmat,is.folded,nb.time=500,
         conv.lim=10^{-3},loc.solv="COBYLA",
                         control=list(maxeval=20000, ftol_abs=10^(-5),stopval=0)){
  
  train.SFS <- rowSums(SFS.groups[,-i.group])
  
  res.train <- MinScore(train.SFS,n.samples,knots,theta.prm,alpha,Wmat,Vmat,is.folded,
                        nb.time=nb.time,conv.lim=conv.lim,loc.solv=loc.solv,control=control)
  
  evec <- EjFct(cumsum(res.train$par),knots,n.samples,nb.time=nb.time)

  expSFS <- sum(SFS.groups[,i.group])*(Wmat%*%evec/sum(Vmat*evec))

  if(is.folded){
    UFexpSFS <- expSFS ## the fitted SFS
    if(length(UFexpSFS) %% 2 == 0){
      expSFS <- (UFexpSFS +rev(UFexpSFS))[1:(length(UFexpSFS)/2)]
    } else{
      expSFS <- (UFexpSFS +rev(UFexpSFS))[1:(floor(length(UFexpSFS)/2))]
      expSFS <- c(expSFS,UFexpSFS[(length(UFexpSFS)+1)/2])
    }
  }
  
  sum((SFS.groups[,i.group]-expSFS)^2/expSFS)
}
