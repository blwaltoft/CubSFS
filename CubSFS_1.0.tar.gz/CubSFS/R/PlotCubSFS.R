
#' @export

PlotCubSFS <-
function(n.samples,mu,seqlen,genyr,
         SFS.res,boot.res=NULL,
         abstime=NULL,
         is.folded=F,nb.time=500){
  
  if(is.null(abstime)){
    stop("Specify the time points in years back in time, in which to evalute the population size")
    
  } else {
    if(max(abstime)<genyr){warning("The abstime must be in years back in time")}

    Vmat <- VFunction(n.samples)
    
    evec.spl <- EjFct(cumsum(SFS.res$ResSpline$par),SFS.res$knots,n.samples,nb.time=nb.time)
    
    nb.seg.sites <- sum(SFS.res$SFS)
    thetaHalfGenome <- nb.seg.sites/sum(Vmat*evec.spl)
    
    MutRateHalf <- thetaHalfGenome/seqlen
    N02 <- (MutRateHalf)/mu
    
    tt <- abstime/(genyr*N02)
    
    Lambda <- SplineFct(tt,cumsum(SFS.res$ResSpline$par),SFS.res$knots)
    
    ii <- findInterval(tt,SFS.res$knots)
    lambda <- Lambda$bb.spl[ii]+2*Lambda$cc.spl[ii]*(tt-SFS.res$knots[ii])+
      3*Lambda$dd.spl[ii]*(tt-SFS.res$knots[ii])^2
    
    Nt <- N02/(2*lambda)
    
    Ntdf <- data.frame(abstime=abstime, Nt=Nt)
    colnames(Ntdf) <- c("time","Nt")
    
    
    
    if(!is.null(boot.res)){
      if(length(which(unlist(lapply(boot.res,function(x) identical(x$knots,SFS.res$knots)))==F))!=0){
        stop("The time points of the bootstrap samples must equal that of the observed SFS")
      } else {
        bootNt <-lapply(boot.res,function(boot){
                                    if(boot$ResSpline$convergence!=3 &
                                       all( boot$ResSpline$par-diff(boot$knots) < 10^(-5) )){
                                      return(NULL)
                                    } else {
                                      evec.spl <- EjFct(cumsum(boot$ResSpline$par),boot$knots,n.samples,nb.time=nb.time)
                                      
                                      nb.seg.sites <- sum(boot$SFS)
                                      thetaHalfGenome <- nb.seg.sites/sum(Vmat*evec.spl)
                                      MutRateHalf <- thetaHalfGenome/seqlen
                                      N02 <- (MutRateHalf)/mu
                                      
                                      tt <- abstime/(genyr*N02)
                                      
                                      Lambda <- SplineFct(tt,cumsum(boot$ResSpline$par),boot$knots)
                                      
                                      ii <- findInterval(tt,boot$knots)
                                      lambda <- Lambda$bb.spl[ii]+2*Lambda$cc.spl[ii]*(tt-boot$knots[ii])+
                                        3*Lambda$dd.spl[ii]*(tt-boot$knots[ii])^2
                                      
                                      Nt <- N02/(2*lambda)
                                      
                                      return(Nt)
                                    }
          })
        NtMat <- matrix(unlist(bootNt),nrow=length(abstime))
        conf <- apply(NtMat,1,function(x)quantile(x,probs=c(0.025,0.5,0.975)))
        Ntdf <- cbind(Ntdf,t(conf))
        colnames(Ntdf) <- c("time","Nt","LCL","median","UCL")
        
        plot(Ntdf$time,Ntdf$Nt,xlab="time",ylab=expression(N(t)),ylim=c(min(Ntdf[,-1]),max(Ntdf[,-1])),type="l")
        
        lines(Ntdf$time,Ntdf$LCL,type="l",lty=2)
        lines(Ntdf$time,Ntdf$median,type="l",lty=2)
        lines(Ntdf$time,Ntdf$UCL,type="l",lty=2)
        Nt.p <- recordPlot()
          
        Ntboot <- cbind(abstime,NtMat)
        Ntboot <- data.frame(Ntboot)
        names(Ntboot) <- c("time",paste("Boot",1:length(boot.res),sep=""))
        
        return(list(Ntdf=Ntdf,Ntboot=Ntboot,Ntplot=Nt.p))
        
      }
    } else {
      
      plot(Ntdf$time,Ntdf$Nt,xlab="time",ylab=expression(N(t)),ylim=c(min(Ntdf[,-1]),max(Ntdf[,-1])),type="l")
      Nt.p <- recordPlot()
      
      
      return(list(Ntdf=Ntdf,Ntplot=Nt.p))
    }
    
    
    
    
    
  }
}
