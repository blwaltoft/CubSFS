#' caluclate \eqn{W_{ij}}
#' 
#' @param i row \code{i} of \eqn{W}
#' @param n the number of sequences.
#' 
#' @return an vector of length (n-1) holding the Code{i}'th row of \eqn{W}
#'
#'  @references 
#' Polanski, A. and Kimmel, M. (2003), "New Explicit Expressions for Relative Frequencies of Single-Nucleotide Polymorphisms With Application 
#' to Statistical Inference on Population Growth." Genetics, 165, 427-436.
#' 
#' @export

WijFunction <-
function(i,n){
  Wi <- rep(0,n-1)
  Wi[1] <- 6/(n+1)
  Wi[2] <- 30*(n-2*i)/((n+1)*(n+2))
  for (j in 3:(n-1)){
    Wi[j] <- -(1+(j-1))*(3+2*(j-1))*(n-(j-1))/
      ((j-1)*(2*(j-1)-1)*(n+(j-1)+1))*
      Wi[j-2]+
      ((3+2*(j-1))*(n-2*i))/((j-1)*(n+(j-1)+1))*Wi[j-1]
  }
  return(Wi)
}
