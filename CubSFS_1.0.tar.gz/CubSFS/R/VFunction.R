#' A Polanski and Kimmel matrix
#' 
#' @param n number of sequences
#' 
#' @return a vector of length n-1
#' 
#' @references 
#' Polanski, A. and Kimmel, M. (2003), "New Explicit Expressions for Relative Frequencies of Single-Nucleotide Polymorphisms With Application 
#' to Statistical Inference on Population Growth." Genetics, 165, 427-436.
#' 
#' @export

VFunction <-
function(n.samples){
  return(as.vector(sapply(2:n.samples,VjFunction,n=n.samples)))
}
