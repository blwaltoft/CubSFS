#' Evaluate the Spline.
#'
#' The parameters of the spline \eqn{\Lambda(t)}, the value of the spline in a given time point \eqn{t}, and the roughness penalty 
#' is evaluate given time points \eqn{t_0 = 0< t_1< t_2< \ldots< t_m} and values \eqn{a_0 = \Lambda(t_0) = 0, \Lambda(t_1) = a_1,..., \Lambda(t_m) = a_m}
#' for a spline 
#' \deqn{\Lambda(t) = a_i + b_i (t - t_i) + c_i (t-t_i)^2 + d_i (t-t_i)^3 for t_i \leq t < t_{i+1},}{\Lambda (t) = a_i + b_i (t - t_i) + c_i (t-t_i)^2 + d_i (t-t_i)^3 for t_i \le t < t_{i+1},} 
#' where \eqn{\Lambda'(0)=b_0=1} and \eqn{\Lambda(t) = a_m + b_m ( t - t_m )} for \eqn{t_m < t}.
#'
#' The parameters of the spline is found by solving the linear equation system described by Waltoft and Hobolth (2017).
#' 
#' The penalty is 
#' \deqn{\int_0^{\infty} (\Lambda''(t))^2 dt}{intergral_0^{\infty} ( \Lambda''(t) )^2 dt,}
#' which is also found by solving a linear equation system, also described by Waltoft and Hobolth (2017).
#'
#' @param tt a vector with time points in which to evaluate the spline
#' @param a a vector of length \eqn{m} holding the values \eqn{a_1,a_2,...,a_m}, assuming \eqn{a_0=0}.
#' @param knots a vector of time points \eqn{0,t_1,t_2,...,t_m} in which the value of the spline is \code{a}, 
#' notice including \eqn{t_0=0}.
#' 
#' @return
#' A list of five elements
#' \describe{
#'   \item{spline}{a data frame with two columns and \code{[length(tt)] rows}. First column is \code{tt}, second column is the 
#'   spline evaluated in corresponding value of \code{tt}.}
#'   \item{penalty}{an integer. The roughness penalty.}
#'   \item{bb.spl}{a vector of length \eqn{m+1}, the coefficient for the term of first order \eqn{b_i} for \eqn{i=0,1,\ldots,m},
#'   where \eqn{b_0 = 1}.}
#'   \item{cc.spl}{a vector of length \eqn{m+1}, the coefficient for the term of second order \eqn{c_i} for \eqn{i=0,1,\ldots,m-1} 
#'   and \eqn{c_m = 0}.}
#'   \item{dd.spl}{a vector of length \eqn{m+1}, the coefficient for the term of third order \eqn{d_i} for \eqn{i=0,1,\ldots,m-1}  
#'   and \eqn{d_m = 0}.}
#' }
#' 
#' @references Waltoft and Hobolth (2017) Non-Parametric Estimation Of Population Size Changes From The Site Frequency Spectrum, 
#' doi: https://doi.org/10.1101/125351 
#' 
#' @examples 
#' 
#' tt <- seq(0,5,len=20)
#' knots <- c(0,1,2,3,4)
#' a <- c(0.5,1,3,4)
#' 
#' spl <- SplineFct(tt,a,knots)
#' spl
#' plot(spl$spline$time,spl$spline$value,type="l") 
#' 
#' @export

SplineFct <-
function(tt,a,knots){
  n.knots <- length(knots)
  h <- diff(knots) ## h_i=t_{i+1}-t_{i}

  Qmat <- matrix(0,nrow=n.knots-1,ncol=n.knots)
  Qmat[1,1:2] <- c(-1,1/(h[1]))
  Qmat[2,1:3] <- c(-1,-1/h[2],1/h[2])
  if(n.knots>3){
    for( i in 3:(n.knots-1)){
      Qmat[i,(i-1):(i+1)] <- c(1/h[i-1],-(1/h[i-1]+1/h[i]),1/h[i])
    }
  }

  Rmat <- matrix(0,nrow=n.knots-1,ncol=n.knots-1)
  Rmat[1,1:2] <- c(2*h[1],h[1])
  Rmat[2,1:3] <- c(3*h[1],3*h[1]+2*h[2],h[2])
  if(n.knots>4){
    for(i in 3:(n.knots-2)){
      Rmat[i,(i-1):(i+1)] <- c(h[i-1],2*(h[i-1]+h[i]),h[i])
    }
  }
  Rmat[n.knots-1,(n.knots-2):(n.knots-1)] <- c(h[n.knots-2],2*(h[n.knots-2]+h[n.knots-1]))
  Rmat <- 1/6*Rmat

  ## calculate cc.spl=c(c_0,c_1,...,c_{n-1},0) length=n.knots
  mm.spl <- solve(Rmat)%*%Qmat%*%matrix(c(1,a),ncol=1)
  mm.spl <- c(mm.spl,0)
  cc.spl <- mm.spl/2

  ##calculate dd.spl=c(d_0,d_1,...,d_{n-1},0) length=n.knots
  dd.spl <- (mm.spl[2:n.knots]-mm.spl[1:(n.knots-1)])/(6*h)
  dd.spl <- c(dd.spl,0) ## adding information on the spline after time t_n

  ## calculate bb.spl=c(1,b_1,b_2,...,b_{n-1},b_n) length=n.knots
  bb.spl0 <- 1
  bb.spln <-(a[n.knots-1]-a[n.knots-2])/h[n.knots-1]+h[n.knots-1]*mm.spl[n.knots-1]/6
  bb.spli <- (a[2:(n.knots-1)]-a[1:(n.knots-2)])/h[2:(n.knots-1)]-(2*h[2:(n.knots-1)]*mm.spl[2:(n.knots-1)]+h[2:(n.knots-1)]*mm.spl[3:n.knots])/6
  bb.spl <- c(bb.spl0,bb.spli,bb.spln)

  ## adding a_0=0 to a
  aa.spl <- c(0,a)

  ## evaluating the spline in points tt
  ii <- findInterval(tt,knots)
  y.spl <- aa.spl[ii]+bb.spl[ii]*(tt-knots[ii])+cc.spl[ii]*(tt-knots[ii])^2+dd.spl[ii]*(tt-knots[ii])^3

  ## calculating the roughness penalty.
  ## changing Q
  QmatC <- Qmat
  QmatC[2,1:3] <- c(0,-(1/h[1]+1/h[2]),1/h[2])

  SmPenalty <- matrix(mm.spl[-n.knots],nrow=1)%*%QmatC%*%matrix(c(1,a),ncol=1)

  ## generate output
  out <- list()
  out$spline <- data.frame(time=tt,value=y.spl)
  out$penalty <- SmPenalty
  out$dd.spl <- dd.spl
  out$cc.spl <- cc.spl
  out$bb.spl <- bb.spl
  return(out)
}
