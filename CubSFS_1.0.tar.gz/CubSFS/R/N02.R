#' Estimate the present population size
#' 
#' Given an estimated spline \eqn{\Lambda(t)} and the probability of a mutation between two generations \eqn{\mu} 
#' the present population size is estimated as
#' \deqn{2N(0) = \theta / 2 / \mu}
#' where \eqn{\theta / 2} is determined from the estimated spline.
#' 
#' @param rawSFS the observed SFS
#' @param res A list, which is the result from the \code{\link[nloptr]{auglag}} function.
#'   \describe{
#'     \item{par}{The estimated parameter. The optimal solution found so far}
#'     \item{value}{The value of the score function corresponding to \code{par}}
#'     \item{iter}{the number of iterations used}
#'     \item{global_solver}{The global NLOPT solver used}
#'   \item{local_solver}{The local NLOPT solver used}
#'     \item{convergence}{interger code indicating successfull completion (3), running out of iterations (5), 
#'     other successfull completion (>0), or error number (<0)}
#'     \item{message}{character string produced by NLOPTR and giving additional information}
#'    }
#' @param knots the time points used when obtaining \code{res}.
#' @param n.samples the number of sequences used to generate \code{rawSFS}.
#' @param nb.basepair the total number of base pairs in one sequence.
#' @param mu the probability of a mutation pr. basepair between generations.
#' 
#' @details
#' 
#' The mutation rate pr. basepair (in coalescent units) is determined as
#' \deqn{\frac{\theta}{2}=\frac{\sum_{i=1}^{n-1}\E[\xi_i]}{G\left(\sum_{j=2}^n e_j(\Lambda)V_j\right)}.}{\theta / 2 = (\sum_{i=1}^{n-1} E[\xi_i]) / {G * \sum_{j=2}^n e_j(\Lambda) V_j)}.}
#' Here \eqn{G} is \code{nb.basepair}.
#'  
#' @return An interger \eqn{2*N(0)}.
#' 
#' @export


N02 <- function(rawSFS,res,knots,n.samples,nb.basepair,mu){
  
  Vmat <- VFunction(n.samples)
  
  evec.spl <- EjFct(res,knots,n.samples)
  
  nb.seg.sites <- sum(rawSFS)
  thetaHalfGenome <- nb.seg.sites/sum(Vmat*evec.spl)
  
  MutRateHalf <- thetaHalfGenome/nb.basepair
  N02 <- (MutRateHalf)/mu
  return(N02)
}