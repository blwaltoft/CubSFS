#' calculate \eqn{V_j}
#' 
#' @param n the number of sequences
#' @param j the entry V to calculate
#' 
#' @return an interger
#' 
#'  @references 
#' Polanski, A. and Kimmel, M. (2003), "New Explicit Expressions for Relative Frequencies of Single-Nucleotide Polymorphisms With Application 
#' to Statistical Inference on Population Growth." Genetics, 165, 427-436.
#' 
#' @export


VjFunction <-
function(n,j){
  return( (2*j-1)*prod( (n-j+1):(n-1)/(n+1):(n+j-1) )*( 1+(-1)^j) )
}
